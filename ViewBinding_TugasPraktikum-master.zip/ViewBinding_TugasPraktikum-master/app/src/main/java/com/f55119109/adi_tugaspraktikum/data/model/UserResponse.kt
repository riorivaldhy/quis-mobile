package com.f55119109.adi_tugaspraktikum.data.model

data class UserResponse(
    val items : ArrayList<User>
)
