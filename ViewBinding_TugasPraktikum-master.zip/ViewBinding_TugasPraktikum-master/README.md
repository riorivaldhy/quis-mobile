# ViewBinding_TugasPraktikum
Tugas Implementasi View Binding Pada Praktikum 4 : Android Web API 

GENERATE TOKEN PRIBADI UNTUK MENCOBA, MASUKKAN DI INTERFACE "Api" YANG BERADA DI DALAM PROJECT.
JIKA TIDAK, API-NYA TIDAK AKAN BERJALAN.

dibuat kembali menggunakan bahasa kotlin
